﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        
        double Num1, Num2, Resultado; //Globais

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl == btnSair)
                {
                return; 
            }
            if (!Double.TryParse(txtNum1.Text, out Num1))
                

            {
                MessageBox.Show("Valor inválido!");
                txtNum1.Focus();
                    }


        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtNum2.Text, out Num2))


            {
                MessageBox.Show("Valor inválido!");
                txtNum2.Focus();
            }
        }

        private void txtResultado_Validated(object sender, EventArgs e)
        {
            
            if (!Double.TryParse(txtResultado.Text, out Resultado))


            {
                MessageBox.Show("Valor inválido!");
                txtResultado.Focus();
            }
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            Resultado = Num1 + Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            Resultado = Num1 - Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnMultplicar_Click(object sender, EventArgs e)
        {
            Resultado = Num1 * Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            if (Num2 == 0)
                MessageBox.Show("Numero 2 inválido!");

            else
            Resultado = Num1 / Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtResultado.Clear();
            txtNum1.Clear();
            txtNum2.Clear();
            Num1 = 0;
            Num2 = 0;
            Resultado = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

       
    }
}