﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double PesoAtual, Altura, Imc;



        public Form1()
        {
            InitializeComponent();
        }



        private void mtbPesoAtual_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(mskbxPesoAtual.Text, out PesoAtual) ||
                (PesoAtual <=0))
            {
                MessageBox.Show("Peso inválido");
                mskbxPesoAtual.Focus();
            }
        }

       

        private void mtbAltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(mskbxAltura.Text, out Altura) || 
                (Altura <= 0))
            {
                MessageBox.Show("Altura inválida");
                mskbxAltura.Focus();
            }
        }

      

        private void txtImc_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtImc.Text, out Imc))
            {
                MessageBox.Show("IMC Inválido");
                txtImc.Focus();
            }
        }

       

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Imc = PesoAtual / (Altura * Altura);
            Imc = Math.Round(Imc, 1);
            txtImc.Text = Imc.ToString();
            
            if (Imc < 18.5)
                MessageBox.Show("Magreza - Obesidade (Grau) = 0");
              else if (Imc <= 24.9)
                MessageBox.Show("Normal - Obesidade (Grau) = 0");
               else if (Imc <= 29.9)
                 MessageBox.Show("Sobrepeso - Obesidade (Grau) = 1");
                else if (Imc <= 39.9)
                  MessageBox.Show("Obesidade - Obesidade (Grau) = 2");
                  else 
                    MessageBox.Show("Obesidade Grave - Obesidade (Grau) = 3");


        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPesoAtual.Clear();
            mskbxAltura.Clear();
            txtImc.Clear(); 
            PesoAtual = 0;
            Altura = 0;
            Imc = 0;
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }


    }
}

    

