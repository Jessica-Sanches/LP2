﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;



        public Form1()
        {
            InitializeComponent();
        }



        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtValorA.Text, out valorA))


            {
                MessageBox.Show("Valor inválido!");
                txtValorA.Focus();
            }
        }



        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtValorB.Text, out valorB))


            {
                MessageBox.Show("Valor inválido!");
                txtValorB.Focus();
            }
        }

       

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (!Double.TryParse(txtValorC.Text, out valorC))


            {
                MessageBox.Show("Valor inválido!");
                txtValorC.Focus();
            }
        }

       

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((valorA < (valorB + valorC)) && (valorA > (Math.Abs(valorB - valorC))) && (valorB < (valorA + valorC)) &&
                (valorB > Math.Abs(valorA - valorC)) && (valorC < (valorA + valorB)) && (valorC > (Math.Abs(valorA - valorB))))


            {
                if ((valorA == valorB) && (valorB == valorC))

                    MessageBox.Show("O Triângulo é : Equilátero.");

                else if ((valorA != valorB) && (valorA != valorC) && (valorB != valorC))

                    MessageBox.Show("O Triângulo é: Escaleno.");

                else

                    MessageBox.Show("O Triângulo é: Isósceles");





            }
            else
                MessageBox.Show("Não forma um Triângulo!");
        }
             private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
            valorA = 0;
            valorB = 0;
            valorC = 0;
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
        }
    
    


