﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmexercicio4 : Form
    {
        public frmexercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contaNum = 0;

            while (posicao < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[posicao]))
                {
                    contaNum++;
                }
                posicao++;
            }
            MessageBox.Show($" Afrase tem:  {contaNum} números");
        }

        private void bntLocaliza_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            if (posicao > 0)

                MessageBox.Show($"O primeiro caracter em branco está na posição:  {posicao}");

            else
                MessageBox.Show("Não há caractereem branco.");
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetra =0;


            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }

            }
            MessageBox.Show($"A frase tem:  {contaLetra} Letras");
        }
    }
}
