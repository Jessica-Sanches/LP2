﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmexercicio5 : Form
    {
        public frmexercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int Num1 =  0;
            int Num2 = 0;

            if (!int.TryParse(txtNum1.Text, out Num1) || (Num1 <= 0))
            {
                MessageBox.Show("Numero 1 Inválido");
                txtNum1.Focus();
            }
            else if (!int.TryParse(txtNum2.Text, out Num2) || (Num2 <= 0))

            {
                MessageBox.Show("Número 2 inválido");
                txtNum2.Focus();
            }
            Random ObjR = new Random();
            int Sorteado = ObjR.Next(Num1,Num2);
            MessageBox.Show("O número é: " + Sorteado);
        }
    }
}
