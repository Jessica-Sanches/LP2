﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class Frm_Exercicio2 : Form
    {
        int Numero;
        int H;
        public Frm_Exercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int Numero;
            double H = 0;

            Numero = Convert.ToInt32(txtNumero.Text);

            if (Numero <= 0)
            {
                MessageBox.Show("Número informado deve ser inteiro e maior que zero");
                txtNumero.Focus();
            }
            else
            {
                for (int i = 1; i <= Numero; i++)
                {
                    H = H + (1.0 / i);
                }
                MessageBox.Show("Valor de H = " + H.ToString("F2"));
            }
        }
    }
}
