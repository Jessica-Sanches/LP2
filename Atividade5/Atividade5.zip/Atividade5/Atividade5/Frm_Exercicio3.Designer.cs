﻿namespace Atividade5
{
    partial class Frm_Exercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFrase = new System.Windows.Forms.Label();
            this.txtFrase = new System.Windows.Forms.TextBox();
            this.btnFrase = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFrase.Location = new System.Drawing.Point(28, 108);
            this.lblFrase.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(224, 18);
            this.lblFrase.TabIndex = 0;
            this.lblFrase.Text = "Digite uma palavra ou uma frase:";
            this.lblFrase.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtFrase
            // 
            this.txtFrase.Location = new System.Drawing.Point(31, 151);
            this.txtFrase.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtFrase.Name = "txtFrase";
            this.txtFrase.Size = new System.Drawing.Size(488, 20);
            this.txtFrase.TabIndex = 1;
            // 
            // btnFrase
            // 
            this.btnFrase.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnFrase.Location = new System.Drawing.Point(30, 266);
            this.btnFrase.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnFrase.Name = "btnFrase";
            this.btnFrase.Size = new System.Drawing.Size(212, 67);
            this.btnFrase.TabIndex = 2;
            this.btnFrase.Text = "Testar Palíndromo";
            this.btnFrase.UseVisualStyleBackColor = false;
            this.btnFrase.Click += new System.EventHandler(this.btnFrase_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLimpar.Location = new System.Drawing.Point(311, 266);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(207, 67);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Frm_Exercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnFrase);
            this.Controls.Add(this.txtFrase);
            this.Controls.Add(this.lblFrase);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Frm_Exercicio3";
            this.Text = "Frm_Exercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.TextBox txtFrase;
        private System.Windows.Forms.Button btnFrase;
        private System.Windows.Forms.Button btnLimpar;
    }
}