﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class Frm_Exercicio3 : Form
    {
        public Frm_Exercicio3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnFrase_Click(object sender, EventArgs e)
        {
           string frase, textoLimpo = "", invertido = ""; 
           frase = txtFrase.Text.ToUpper();
           if (frase.Length > 50)
           {    
                MessageBox.Show("A frase deve ter no máximo 50 caracteres.");
                txtFrase.Focus();
           }
           else
           {    
                for (int i = 0; i < frase.Length; i++)
                {   
                    if (frase[i] != ' ')
                    {   
                        textoLimpo += frase[i];
                    }    
                }   
                for (int i = textoLimpo.Length - 1; i >= 0; i--)
                {   
                    invertido += textoLimpo[i];
                }   
                if (textoLimpo == invertido)
                {   
                    MessageBox.Show("É um palíndromo!");
                }   
                else    
                {   
                    MessageBox.Show("Não é um palíndromo.");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtFrase.Text = "";
            txtFrase.Focus();
        }
    }
}
