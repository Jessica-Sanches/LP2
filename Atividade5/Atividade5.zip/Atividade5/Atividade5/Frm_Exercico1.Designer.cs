﻿namespace Atividade5
{
    partial class FrmExercico1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFrase = new System.Windows.Forms.Label();
            this.rtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnParLetras = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFrase.Location = new System.Drawing.Point(19, 11);
            this.lblFrase.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(115, 18);
            this.lblFrase.TabIndex = 0;
            this.lblFrase.Text = "Digite uma frase";
            // 
            // rtxtFrase
            // 
            this.rtxtFrase.Location = new System.Drawing.Point(21, 31);
            this.rtxtFrase.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rtxtFrase.Name = "rtxtFrase";
            this.rtxtFrase.Size = new System.Drawing.Size(531, 158);
            this.rtxtFrase.TabIndex = 2;
            this.rtxtFrase.Text = "";
            // 
            // btnEspaco
            // 
            this.btnEspaco.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEspaco.Location = new System.Drawing.Point(22, 211);
            this.btnEspaco.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(118, 46);
            this.btnEspaco.TabIndex = 3;
            this.btnEspaco.Text = "Espaço em Branco";
            this.btnEspaco.UseVisualStyleBackColor = false;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLetraR.Location = new System.Drawing.Point(236, 211);
            this.btnLetraR.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(118, 46);
            this.btnLetraR.TabIndex = 4;
            this.btnLetraR.Text = "Nº letra R";
            this.btnLetraR.UseVisualStyleBackColor = false;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnParLetras
            // 
            this.btnParLetras.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnParLetras.Location = new System.Drawing.Point(439, 211);
            this.btnParLetras.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnParLetras.Name = "btnParLetras";
            this.btnParLetras.Size = new System.Drawing.Size(113, 46);
            this.btnParLetras.TabIndex = 5;
            this.btnParLetras.Text = "Nº par de letras";
            this.btnParLetras.UseVisualStyleBackColor = false;
            this.btnParLetras.Click += new System.EventHandler(this.btnParLetras_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLimpar.Location = new System.Drawing.Point(91, 282);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(395, 54);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // FrmExercico1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnParLetras);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.rtxtFrase);
            this.Controls.Add(this.lblFrase);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FrmExercico1";
            this.Text = "FrmExercico1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.RichTextBox rtxtFrase;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnParLetras;
        private System.Windows.Forms.Button btnLimpar;
    }
}