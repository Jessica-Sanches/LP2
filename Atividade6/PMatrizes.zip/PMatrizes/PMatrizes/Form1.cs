﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o Número {i + 1}", "Entarda de Dados");



                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor Inválido");
                    i--;

                }
            }

            Array.Reverse(vetor);
            aux = "";
            foreach (int x in vetor)
                aux += x + "\n";

            MessageBox.Show("aux");


        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList();
            lista.Add("Ana");
            lista.Add("André");
            lista.Add("Beatriz");
            lista.Add("Camila");
            lista.Add("João");
            lista.Add("Joana");
            lista.Add("Otávio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");


            lista.Remove("Otávio");

            string resultado = string.Join("\n", lista.Cast<string>());
            MessageBox.Show("Lista de Nomes: \n\n" + resultado);

        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[2, 3];
            string aux = "";
            Double media = 0;
      
            string resultado = "";

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    aux = Interaction.InputBox($"Digite a nota {j + 1} do aluno{i + 1}");

                    if (!double.TryParse(aux, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida.");
                        j--;
                    }
                    //notas[i,j] = valor;
                }
            }

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                resultado += $"  Aluno {i + 1}  Média {media}"; 
            }
            MessageBox.Show(resultado);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            FormAtividade4 tela = new FormAtividade4();
            tela.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            FormAtividade5 tela = new FormAtividade5();
            tela.Show();
        }
    }
    
}
