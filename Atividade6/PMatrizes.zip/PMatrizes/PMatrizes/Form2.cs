﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace PMatrizes
{
    public partial class FormAtividade4 : Form
    {
        public FormAtividade4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];

            // Limpa o ListBox
            lbNomes.Items.Clear();

            // Entrada dos nomes
            for (int i = 0; i < 10; i++)
            {
                string nome = "";

                do
                {
                    nome = Interaction.InputBox($"Digite o nome da pessoa {i + 1}:", "Entrada de Dados", "");






                    if (nome != null)  
                    {
                        nome = nome.Trim();
                    }
                    else
                    {
                        nome = "";  // Se cancelar, trata como vazio
                    }

                    if (nome == "")
                    {
                        MessageBox.Show("Nome Inválido!");
                    }       
                           
                        
                    

                }
                while (nome == "");

                
                nomes[i] = nome;

                
                string nomeSemEspaco = nome.Replace(" ", "");
                tamanhos[i] = nomeSemEspaco.Length;
            }

            
            for (int i = 0; i < 10; i++)
            {
                string texto = $"o nome:  {nomes[i]} tem {tamanhos[i]} caracteres";
                lbNomes.Items.Add(texto);
            }
        }
    }
}
    


