﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class FormAtividade5 : Form
    {
        public FormAtividade5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            // Quantidade de alunos
            int N = 3;

            // Matriz de respostas
            string[,] respostas = new string[N, 10];

            // Gabarito
            string[] gabarito = { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };

            // Limpa ListBox
            lbNotas.Items.Clear();

            // Entrada de respostas
            for (int aluno = 0; aluno < N; aluno++)
            {
                for (int questao = 0; questao < 10; questao++)
                {
                    string resposta;

                    do
                    {
                        resposta = Interaction.InputBox(
                            $"Aluno {aluno + 1} - Digite a resposta da questão {questao + 1}",
                            "Prova",
                            ""
                        );

                        resposta = resposta.ToUpper().Trim();

                        if (resposta != "A" &&
                            resposta != "B" &&
                            resposta != "C" &&
                            resposta != "D" &&
                            resposta != "E")
                        {
                            MessageBox.Show("Digite apenas A, B, C, D ou E", "Erro");
                        }






                    } while (
                        resposta != "A" &&
                        resposta != "B" &&
                        resposta != "C" &&
                        resposta != "D" &&
                        resposta != "E");
                    

                    // Guarda resposta
                    respostas[aluno, questao] = resposta;
                }
            }

            // Comparação com gabarito
            for (int aluno = 0; aluno < N; aluno++)
            {
                for (int questao = 0; questao < 10; questao++)
                {
                    if (respostas[aluno, questao] == gabarito[questao])
                    {
                        lbNotas.Items.Add(
                            $"O aluno:{aluno + 1} acertou questão:{questao + 1} era {gabarito[questao]} escolheu {respostas[aluno, questao]}"
                        );
                    }
                    else
                    {
                        lbNotas.Items.Add(
                            $"O aluno:{aluno + 1} errou questão:{questao + 1} era {gabarito[questao]} escolheu {respostas[aluno, questao]}"
                        );
                    }
                }
            }
        }
    }
    }

    

