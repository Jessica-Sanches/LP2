using System.Diagnostics.Eventing.Reader;

namespace AulaPratica1
{
    public partial class Form1 : Form
    {
        double raio, altura, volume; /*Globais*/
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar)
            {
                return;
            }
            if (!Double.TryParse(txtRaio.Text, out raio) ||
                    (raio <= 0))
            {
                MessageBox.Show("raio inv�lido!");
                txtRaio.Focus();
            }

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar)
            {
                return;
            }
            if (!Double.TryParse(txtAltura.Text, out altura) ||
                   (altura <= 0))
            {
                MessageBox.Show("altura inv�lido!");
                txtAltura.Focus();
            }
        }

        private void txtVolume_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtVolume.Text, out volume) ||
                   (volume <= 0))
            {
                MessageBox.Show("volume inv�lido!");
                txtVolume.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVolume.Text = volume.ToString("N2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Clear();
            txtAltura.Clear();
            txtVolume.Clear();
            raio = 0;
            altura = 0;
            volume = 0;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
    