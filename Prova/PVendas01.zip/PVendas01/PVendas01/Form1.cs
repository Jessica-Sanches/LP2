﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        { 
           

            {
                double[,] valores = new double[3, 4];                                                               // matriz principal - 7 linhas (dias), 5 colunas (produtos)
                double[] totalPorMes = new double[3];
                double totalMes = 0;
                double valorDaSemana = 0;
                string[] semana = { "1", "2", "3" };    
                
                for (int i = 0; i < 3; i++)                                                                         //loop para dias da semana
                {
                    for (int j = 0; j < 4; j++)                                                                     //loop para produtos
                    {
                        string aux = Interaction.InputBox($"Digite o valor da venda da Semana:{j + 1} " +                   // exemplo: produto 4+1 = produto 5 (printa na tela)
                            $"no semama  {semana[i]}", "Entrada de Dados");                                         // string aux poderia ser string entrada, ou qualquer outro nome de variavel. 
                                                                                                                    // Apenas saber que será a variavel de recebimento das entradas, antes de transporta-las a a matriz.
                        if (aux == "")
                            return;                                                                                 // se o usuario cancelar ou deixar vazio, encerra o método

                        if (!double.TryParse(aux, out valores[i, j]) || valores[i, j] <= 0)
                        {
                            MessageBox.Show("Valor Inválido!");
                            j--;
                        }
                    }

                }

                double totalGeral = 0;

                for (int i = 0; i < 3; i++)                                                                         // loop dos dias
                {
                    for (int j = 0; j < 4; j++)                                                                     // loop dos produtos
                    {
                        totalPorMes[i] += valores[i, j];                                                            // acumula o total do dia
                    }
                    totalGeral += totalPorMes[i];                                                                   // adiciona o dia ao total geral
                }

                
                lstbxVendas.Items.Clear();                                                                         // limpa exibições anteriores -- também pode ser colocada sozinha no click do botão LIMPAR
                lstbxVendas.Items.Add("TOTAL POR MÊS");

                for (int i = 0; i < 3; i++)
                {
                    
                        double valorSemana = valorDaSemana;
                        lstbxVendas.Items.Add(
                    $"{semana[i]}: {totalMes:N0} L -> {valorDaSemana:C2}");
                        lstbxVendas.Items.Add($"{semana[i],-15}\t R$ {totalPorMes[i]:F2}");
                    }
                                                                                                                  // \t tabulação para separar o nome do valor
                lstbxVendas.Items.Add(
               $"TOTAL GERAL: {totalMes:N0} L -> {valorDaSemana:C2}");                                                                                                   // F2 formata o número com 2 casas decimais
                lstbxVendas.Items.Add("---------------------------------");
                lstbxVendas.Items.Add($"TOTAL GERAL: R$ {totalGeral:F2}");
            }
        }
    }

}
      

    

